class RespuestaComentario {
  final String id;
  final String comentarioId;
  final String usuario;
  final String avatarUrl;
  final String fecha;
  final String respuesta;
  final int likes;
  final bool miLike;
  final bool editado;
  final bool eliminado;
  final bool esMia;

  const RespuestaComentario({
    required this.id,
    required this.comentarioId,
    required this.usuario,
    required this.avatarUrl,
    required this.fecha,
    required this.respuesta,
    required this.likes,
    required this.miLike,
    required this.editado,
    required this.eliminado,
    required this.esMia,
  });

  factory RespuestaComentario.fromJson(Map<String, dynamic> json) {
    return RespuestaComentario(
      id: json["id"]?.toString() ?? "",
      comentarioId: json["comentarioId"]?.toString() ?? "",
      usuario: json["usuario"]?.toString() ?? "",
      avatarUrl:
          json["avatarUrl"]?.toString() ??
          json["fotoUrl"]?.toString() ??
          json["photoUrl"]?.toString() ??
          "",
      fecha: json["fecha"]?.toString() ?? "",
      respuesta: json["respuesta"]?.toString() ?? "",
      likes: json["likes"] as int? ?? 0,
      miLike: json["miLike"] as bool? ?? false,
      editado: json["editado"] as bool? ?? false,
      eliminado: json["eliminado"] as bool? ?? false,
      esMia: json["esMia"] as bool? ?? false,
    );
  }
}
