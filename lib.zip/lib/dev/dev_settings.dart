class DevSettings {
  /// null = usar el estado real que llega del servidor.
  static const String? estadoForzado = null;

  // Ejemplos:
  // static const String? estadoForzado = "PREPARANDO";
  //static const String? estadoForzado = "VOTACION";
  // static const String? estadoForzado = "ULTIMAS_HORAS";
  // static const String? estadoForzado = "RESULTADOS";
  // static const String? estadoForzado = "LECTURA";

  //static const int votosDemo = 5;
  //static const int totalDemo = 9;
}
